package com.library.api.auth;

public enum Role {
    ADMIN,
    MEMBER
}