package com.library.api.book;

public class Book {
}
